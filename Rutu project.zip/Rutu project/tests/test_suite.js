/**
 * Markdown Documentation Site Builder - API & Static Asset Integration Test
 */

const http = require('http');

function makeRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(data); } catch (e) {}
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          data: json || data
        });
      });
    });

    req.on('error', reject);
    if (postData) {
      req.write(typeof postData === 'string' ? postData : JSON.stringify(postData));
    }
    req.end();
  });
}

async function runTests() {
  console.log('--- Starting Integration Test Suite ---\n');

  // Test 1: Health Check
  try {
    const health = await makeRequest({
      hostname: 'localhost',
      port: 5000,
      path: '/api/health',
      method: 'GET'
    });
    console.log(`[PASS] GET /api/health -> Status ${health.statusCode}`);
    console.log('       Response:', health.data);
  } catch (e) {
    console.error('[FAIL] GET /api/health failed:', e.message);
  }

  // Test 2: Static Frontend Routes
  const staticRoutes = ['/', '/editor', '/my-docs', '/style.css', '/js/api.js', '/editor.js', '/docs.js'];
  for (const route of staticRoutes) {
    try {
      const res = await makeRequest({
        hostname: 'localhost',
        port: 5000,
        path: route,
        method: 'GET'
      });
      const ok = res.statusCode === 200;
      console.log(`[${ok ? 'PASS' : 'FAIL'}] GET ${route} -> Status ${res.statusCode} (${typeof res.data === 'string' ? res.data.length : 0} bytes)`);
    } catch (e) {
      console.error(`[FAIL] GET ${route} failed:`, e.message);
    }
  }

  // Test 3: Auth Validation (Empty Body)
  try {
    const authVal = await makeRequest({
      hostname: 'localhost',
      port: 5000,
      path: '/api/auth/register',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, {});
    console.log(`[PASS] POST /api/auth/register (Validation check) -> Status ${authVal.statusCode} (Expected 400)`);
  } catch (e) {
    console.error('[FAIL] POST /api/auth/register failed:', e.message);
  }

  // Test 4: Auth Login Validation (Empty Body)
  try {
    const loginVal = await makeRequest({
      hostname: 'localhost',
      port: 5000,
      path: '/api/auth/login',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, {});
    console.log(`[PASS] POST /api/auth/login (Validation check) -> Status ${loginVal.statusCode} (Expected 400)`);
  } catch (e) {
    console.error('[FAIL] POST /api/auth/login failed:', e.message);
  }

  // Test 5: Protected Route Without Token
  try {
    const protVal = await makeRequest({
      hostname: 'localhost',
      port: 5000,
      path: '/api/docs',
      method: 'GET'
    });
    console.log(`[PASS] GET /api/docs (Auth guard check) -> Status ${protVal.statusCode} (Expected 401)`);
  } catch (e) {
    console.error('[FAIL] GET /api/docs guard failed:', e.message);
  }

  console.log('\n--- Test Suite Execution Completed ---');
}

runTests();
