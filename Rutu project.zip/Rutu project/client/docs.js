/**
 * Markdown Documentation Site Builder - Documents Dashboard Logic (Connected to API)
 * Group 20 | Semester III | RCPIT Shirpur
 */

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const docsGrid = document.getElementById('docsGrid');
  const searchInput = document.getElementById('searchInput');
  const docCountDisplay = document.getElementById('docCountDisplay');
  const previewModal = document.getElementById('previewModal');
  const closeModalBtn = document.getElementById('closeModalBtn');
  const modalCloseActionBtn = document.getElementById('modalCloseActionBtn');
  const modalEditBtn = document.getElementById('modalEditBtn');
  const modalDocTitle = document.getElementById('modalDocTitle');
  const modalDocBody = document.getElementById('modalDocBody');
  const modalCategory = document.getElementById('modalCategory');
  const filterPills = document.querySelectorAll('.filter-pill');

  let activeModalDoc = null;
  let activeFilter = 'all';
  let cachedDocs = [];

  // Default Fallback Documents (used when offline or not signed in)
  const defaultDocs = [
    {
      id: 'doc_1',
      title: 'REST API Authentication & Endpoints Guide',
      category: 'API',
      date: 'Sep 05, 2026',
      words: 680,
      excerpt: 'Comprehensive API specification detailing JWT authentication, header authorizations, rate-limiting, and endpoints for document CRUD operations.',
      content: `# REST API Authentication & Endpoints Guide\n> **Version 1.2.0** &bull; Authored by Backend Team\n\n---\n\n## 1. Authentication Overview\nAll API requests require a JSON Web Token (JWT) provided in the authorization header:\n\`\`\`http\nAuthorization: Bearer <your_jwt_token_here>\n\`\`\`\n\n## 2. Key Endpoints\n\n| Method | Endpoint | Description | Access |\n| :--- | :--- | :--- | :--- |\n| \`POST\` | \`/api/auth/login\` | Authenticate and obtain JWT token | Public |\n| \`GET\` | \`/api/docs\` | List all user documents | Private |\n| \`POST\` | \`/api/docs\` | Create or update a document | Private |\n| \`DELETE\`| \`/api/docs/:id\` | Remove a document from database | Private |\n\n## 3. Response Status Codes\n- \`200 OK\`: Request completed successfully.\n- \`400 Bad Request\`: Missing required fields.\n- \`401 Unauthorized\`: Missing or invalid bearer token.\n- \`500 Internal Server Error\`: Database connection error.\n`
    },
    {
      id: 'doc_2',
      title: 'MySQL Database Schema & ER Model',
      category: 'Database',
      date: 'Sep 03, 2026',
      words: 520,
      excerpt: 'Relational database schema definitions, primary keys, foreign constraints, and indexing strategy for users and documentation revisions.',
      content: `# MySQL Database Schema & ER Model\n> **Project-I Architecture Document** &bull; Group 20\n\n---\n\n## 1. Users Table (\`users\`)\nStores registered students, developers, and administrators.\n\n\`\`\`sql\nCREATE TABLE users (\n  id INT AUTO_INCREMENT PRIMARY KEY,\n  full_name VARCHAR(120) NOT NULL,\n  email VARCHAR(160) UNIQUE NOT NULL,\n  password_hash VARCHAR(255) NOT NULL,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\`\`\`\n\n## 2. Documents Table (\`documents\`)\nStores markdown source text, rendered status, and author foreign keys.\n\n\`\`\`sql\nCREATE TABLE documents (\n  id INT AUTO_INCREMENT PRIMARY KEY,\n  user_id INT NOT NULL,\n  title VARCHAR(200) NOT NULL,\n  content MEDIUMTEXT NOT NULL,\n  category VARCHAR(50) DEFAULT 'General',\n  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE\n);\n\`\`\`\n\n> **Note**: Full-text indexing is applied on \`title\` and \`content\` for fast search queries.\n`
    },
    {
      id: 'doc_3',
      title: 'Frontend Architecture & Styling Standards',
      category: 'UI / UX',
      date: 'Sep 02, 2026',
      words: 610,
      excerpt: 'UI design guidelines, CSS custom properties hierarchy, typography rules with Inter font, and marked.js rendering best practices.',
      content: `# Frontend Architecture & Styling Standards\n> **Design Philosophy**: Minimalist, distraction-free, Notion-like clean workspace.\n\n---\n\n## 1. Color System\nOur palette centers on neutral slate tones with indigo accents:\n- **Canvas**: \`#f8fafc\`\n- **Dark Header**: \`#0f172a\`\n- **Brand Primary**: \`#4f46e5\`\n- **Success Badge**: \`#10b981\`\n\n## 2. Typography Rules\n- Main body: \`Inter, sans-serif\` for readability.\n- Code fences & gutter: \`JetBrains Mono, monospace\`.\n\n## 3. Split-Screen Workflow\nThe editor splits screen real estate evenly:\n1. Left pane for raw Markdown input.\n2. Right pane for instantaneous HTML translation.\n`
    },
    {
      id: 'doc_4',
      title: 'Project Synopsis & System Requirements',
      category: 'Synopsis',
      date: 'Aug 29, 2026',
      words: 890,
      excerpt: 'Official Semester III synopsis document submitted to RCPIT Shirpur. Details group members, project guide Prof. A.Z. Ansari, and objectives.',
      content: `# Semester Project-I Synopsis: Markdown Documentation Site Builder\n**Semester III &bull; Academic Year [2025-26]**  \n**The Shirpur Education Society's R. C. Patel Institute of Technology, Shirpur**\n\n---\n\n### Project Guide:\n**Prof. A.Z. Ansari** &bull; Department of Information Technology\n\n### Group 20 Members:\n1. **Rutuja Mahendrakumar Mahajan** (IT040 &bull; PRN: 251109054)\n2. **Tanushri Nitin Bhadhane** (IT030 &bull; PRN: 251109034)\n3. **Gayatri Vijaysing Thakur** (IT033 &bull; PRN: 251109045)\n4. **Bhumika Chetan Patil** (IT059 &bull; PRN: 251109076)\n\n---\n\n### Abstract Summary:\nDocumentation is an essential part of software engineering. Handcrafting HTML documentation can be tedious. This web application enables users to write simple Markdown and automatically produces structured, elegant documentation websites with zero build configuration.\n`
    }
  ];

  // Fetch Documents from MySQL or Local Fallback
  async function loadDocuments() {
    if (API.isAuthenticated()) {
      try {
        const res = await API.docs.getAll({
          category: activeFilter,
          search: searchInput.value
        });
        if (res.success && Array.isArray(res.documents)) {
          cachedDocs = res.documents;
          return cachedDocs;
        }
      } catch (err) {
        console.warn('[Docs Dashboard] API fetch failed, falling back to local:', err.message);
      }
    }

    // Local Storage Fallback
    let customDocs = [];
    try {
      customDocs = JSON.parse(localStorage.getItem('docbuilder_custom_docs')) || [];
    } catch (e) {
      customDocs = [];
    }

    let deletedIds = [];
    try {
      deletedIds = JSON.parse(localStorage.getItem('docbuilder_deleted_ids')) || [];
    } catch (e) {
      deletedIds = [];
    }

    const filteredDefault = defaultDocs.filter(d => !deletedIds.includes(d.id));
    cachedDocs = [...customDocs, ...filteredDefault];
    return cachedDocs;
  }

  // Render Grid
  async function renderDocs() {
    const docs = await loadDocuments();
    const query = searchInput.value.toLowerCase().trim();

    const filtered = docs.filter(doc => {
      const matchesQuery = !query || 
        doc.title.toLowerCase().includes(query) || 
        (doc.excerpt && doc.excerpt.toLowerCase().includes(query)) || 
        (doc.category && doc.category.toLowerCase().includes(query));

      const matchesFilter = activeFilter === 'all' || 
        (doc.category && doc.category.toLowerCase() === activeFilter.toLowerCase());

      return matchesQuery && matchesFilter;
    });

    docCountDisplay.textContent = filtered.length;

    if (filtered.length === 0) {
      docsGrid.innerHTML = `
        <div class="empty-state">
          <i class="fa-regular fa-folder-open empty-state-icon"></i>
          <h3 style="font-size: 1.25rem; font-weight: 700; color: #0f172a; margin-bottom: 0.5rem;">No documents found</h3>
          <p style="color: var(--text-muted); font-size: 0.95rem; margin-bottom: 1.5rem;">Try adjusting your search terms or create a brand new document.</p>
          <a href="/editor" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-plus"></i> Open Editor
          </a>
        </div>
      `;
      return;
    }

    docsGrid.innerHTML = filtered.map(doc => {
      const cat = doc.category || 'General';
      const badgeClass = cat === 'API' ? 'badge-primary' : 
                         cat === 'Database' ? 'badge-dark' : 
                         cat === 'Synopsis' ? 'badge-success' : 'badge-gray';

      return `
        <article class="doc-card" data-id="${escapeHtml(doc.id)}">
          <div class="doc-card-header">
            <span class="badge ${badgeClass}">${escapeHtml(cat)}</span>
            <span style="font-size: 0.78rem; color: var(--text-subtle);">
              <i class="fa-regular fa-calendar"></i> ${escapeHtml(doc.date || 'Recent')}
            </span>
          </div>

          <h3 class="doc-card-title">
            <a href="javascript:void(0);" class="view-trigger" data-id="${escapeHtml(doc.id)}">${escapeHtml(doc.title)}</a>
          </h3>

          <p class="doc-card-excerpt">${escapeHtml(doc.excerpt || 'No description preview available.')}</p>

          <div class="doc-card-meta">
            <span><i class="fa-solid fa-font"></i> ~${doc.words || 0} words</span>
            <span><i class="fa-solid fa-clock"></i> ~${Math.max(1, Math.ceil((doc.words || 100) / 200))} min read</span>
          </div>

          <div class="doc-card-actions">
            <button class="btn btn-secondary btn-sm view-btn" data-id="${escapeHtml(doc.id)}">
              <i class="fa-solid fa-eye"></i> View
            </button>
            <button class="btn btn-primary btn-sm edit-btn" data-id="${escapeHtml(doc.id)}">
              <i class="fa-solid fa-pen-to-square"></i> Edit
            </button>
            <button class="btn btn-danger btn-sm delete-btn" data-id="${escapeHtml(doc.id)}" title="Delete document">
              <i class="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </article>
      `;
    }).join('');
  }

  // Open Document in Modal
  function openPreviewModal(docId) {
    const doc = cachedDocs.find(d => String(d.id) === String(docId));
    if (!doc) return;

    activeModalDoc = doc;
    modalDocTitle.textContent = doc.title;
    modalCategory.textContent = doc.category || 'Documentation';

    if (typeof marked !== 'undefined') {
      modalDocBody.innerHTML = marked.parse(doc.content || '');
    } else {
      modalDocBody.innerText = doc.content || '';
    }

    previewModal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    previewModal.classList.remove('active');
    document.body.style.overflow = '';
  }

  // Open Document in Editor
  function openInEditor(docId) {
    const doc = cachedDocs.find(d => String(d.id) === String(docId));
    if (!doc) return;

    sessionStorage.setItem('docbuilder_edit_target', JSON.stringify({
      id: doc.id,
      title: doc.title,
      content: doc.content
    }));

    window.location.href = `/editor?id=${doc.id}`;
  }

  // Delete Document
  async function deleteDoc(docId) {
    const doc = cachedDocs.find(d => String(d.id) === String(docId));
    const title = doc ? doc.title : 'Document';

    if (!confirm(`Are you sure you want to delete "${title}"?`)) {
      return;
    }

    // If authenticated and doc has a numeric ID (MySQL record)
    if (API.isAuthenticated() && !isNaN(parseInt(docId, 10))) {
      try {
        await API.docs.delete(docId);
        showToast(`Deleted "${title}" from MySQL database`, 'warning');
        renderDocs();
        return;
      } catch (err) {
        showToast(`Failed to delete from server: ${err.message}`, 'danger');
        return;
      }
    }

    // LocalStorage removal
    let customDocs = [];
    try {
      customDocs = JSON.parse(localStorage.getItem('docbuilder_custom_docs')) || [];
    } catch (e) {
      customDocs = [];
    }

    const customIndex = customDocs.findIndex(d => String(d.id) === String(docId));
    if (customIndex >= 0) {
      customDocs.splice(customIndex, 1);
      localStorage.setItem('docbuilder_custom_docs', JSON.stringify(customDocs));
    } else {
      let deletedIds = [];
      try {
        deletedIds = JSON.parse(localStorage.getItem('docbuilder_deleted_ids')) || [];
      } catch (e) {
        deletedIds = [];
      }
      deletedIds.push(docId);
      localStorage.setItem('docbuilder_deleted_ids', JSON.stringify(deletedIds));
    }

    showToast(`Deleted "${title}" locally`, 'warning');
    renderDocs();
  }

  // Event Delegation for Grid Actions
  docsGrid.addEventListener('click', (e) => {
    const viewBtn = e.target.closest('.view-btn') || e.target.closest('.view-trigger');
    const editBtn = e.target.closest('.edit-btn');
    const deleteBtn = e.target.closest('.delete-btn');

    if (viewBtn) {
      const docId = viewBtn.getAttribute('data-id');
      openPreviewModal(docId);
    } else if (editBtn) {
      const docId = editBtn.getAttribute('data-id');
      openInEditor(docId);
    } else if (deleteBtn) {
      const docId = deleteBtn.getAttribute('data-id');
      deleteDoc(docId);
    }
  });

  // Modal Listeners
  closeModalBtn.addEventListener('click', closeModal);
  modalCloseActionBtn.addEventListener('click', closeModal);
  previewModal.addEventListener('click', (e) => {
    if (e.target === previewModal) closeModal();
  });
  modalEditBtn.addEventListener('click', () => {
    if (activeModalDoc) {
      openInEditor(activeModalDoc.id);
    }
  });

  // Search Input Listener
  searchInput.addEventListener('input', () => {
    renderDocs();
  });

  // Filter Pill Listeners
  filterPills.forEach(pill => {
    pill.addEventListener('click', () => {
      filterPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      activeFilter = pill.getAttribute('data-filter');
      renderDocs();
    });
  });

  // Toast Notifications
  function showToast(message, type = 'success') {
    if (typeof API !== 'undefined' && API.showGlobalToast) {
      API.showGlobalToast(message, type);
      return;
    }

    const toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let iconClass = 'fa-check-circle';
    if (type === 'danger') iconClass = 'fa-triangle-exclamation';
    if (type === 'warning') iconClass = 'fa-circle-exclamation';

    toast.innerHTML = `<i class="fa-solid ${iconClass}"></i> <span>${escapeHtml(message)}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // Listen for login/logout to refresh docs
  window.addEventListener('auth-changed', () => {
    renderDocs();
  });

  // Initial Render
  renderDocs();
});
