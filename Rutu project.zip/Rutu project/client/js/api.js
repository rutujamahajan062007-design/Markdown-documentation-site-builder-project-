/**
 * Markdown Documentation Site Builder - Centralized API & Auth Client
 * Group 20 | Semester III | RCPIT Shirpur
 */

const API = (() => {
  const BASE_URL = '/api';
  const TOKEN_KEY = 'docbuilder_auth_token';
  const USER_KEY = 'docbuilder_auth_user';

  // --- Token & User Storage ---
  function getToken() {
    return localStorage.getItem(TOKEN_KEY) || null;
  }

  function setToken(token) {
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  }

  function getUser() {
    try {
      const u = localStorage.getItem(USER_KEY);
      return u ? JSON.parse(u) : null;
    } catch (e) {
      return null;
    }
  }

  function setUser(user) {
    if (user) {
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(USER_KEY);
    }
  }

  function isAuthenticated() {
    return !!getToken();
  }

  function logout() {
    setToken(null);
    setUser(null);
    window.dispatchEvent(new CustomEvent('auth-changed', { detail: { authenticated: false } }));
  }

  // --- HTTP Request Engine ---
  async function request(endpoint, options = {}) {
    const url = `${BASE_URL}${endpoint}`;
    const headers = {
      ...(options.headers || {})
    };

    const token = getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    if (options.body && !(options.body instanceof FormData) && typeof options.body === 'object') {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }

    try {
      const response = await fetch(url, { ...options, headers });
      const data = await response.json().catch(() => ({}));

      if (response.status === 401 && token) {
        // Token expired or invalid
        console.warn('[API] Session expired or invalid token.');
        logout();
      }

      if (!response.ok) {
        const error = new Error(data.message || `Request failed with status ${response.status}`);
        error.status = response.status;
        error.data = data;
        throw error;
      }

      return data;
    } catch (err) {
      throw err;
    }
  }

  // --- Authentication API ---
  const auth = {
    async register(fullName, email, password, rollNo) {
      const data = await request('/auth/register', {
        method: 'POST',
        body: { fullName, email, password, rollNo }
      });
      if (data.token && data.user) {
        setToken(data.token);
        setUser(data.user);
        window.dispatchEvent(new CustomEvent('auth-changed', { detail: { authenticated: true, user: data.user } }));
      }
      return data;
    },

    async login(email, password) {
      const data = await request('/auth/login', {
        method: 'POST',
        body: { email, password }
      });
      if (data.token && data.user) {
        setToken(data.token);
        setUser(data.user);
        window.dispatchEvent(new CustomEvent('auth-changed', { detail: { authenticated: true, user: data.user } }));
      }
      return data;
    },

    async me() {
      if (!isAuthenticated()) return null;
      try {
        const data = await request('/auth/me');
        if (data.user) {
          setUser(data.user);
        }
        return data.user;
      } catch (e) {
        logout();
        return null;
      }
    },

    logout
  };

  // --- Documents API ---
  const docs = {
    async getAll(params = {}) {
      const query = new URLSearchParams();
      if (params.category && params.category !== 'all') query.append('category', params.category);
      if (params.search && params.search.trim()) query.append('search', params.search.trim());

      const qs = query.toString() ? `?${query.toString()}` : '';
      return await request(`/docs${qs}`);
    },

    async getById(id) {
      return await request(`/docs/${id}`);
    },

    async create(docData) {
      return await request('/docs', {
        method: 'POST',
        body: docData
      });
    },

    async update(id, docData) {
      return await request(`/docs/${id}`, {
        method: 'PUT',
        body: docData
      });
    },

    async delete(id) {
      return await request(`/docs/${id}`, {
        method: 'DELETE'
      });
    },

    async getRevisions(id) {
      return await request(`/docs/${id}/revisions`);
    },

    async restoreRevision(id, version) {
      return await request(`/docs/${id}/revisions/${version}/restore`, {
        method: 'POST'
      });
    }
  };

  // --- Reusable Auth Modal & Navbar Integration ---
  function initAuthUI() {
    injectAuthModal();
    renderHeaderAuth();

    window.addEventListener('auth-changed', () => {
      renderHeaderAuth();
    });
  }

  function renderHeaderAuth() {
    const authArea = document.getElementById('navAuthArea');
    if (!authArea) return;

    const user = getUser();
    if (isAuthenticated() && user) {
      const initials = (user.fullName || 'User')
        .split(' ')
        .map(n => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);

      authArea.innerHTML = `
        <div class="user-profile-chip" id="userMenuBtn" title="Account: ${escapeHtml(user.email)}">
          <div class="user-avatar-circle">${initials}</div>
          <span>${escapeHtml(user.fullName.split(' ')[0])}</span>
          <i class="fa-solid fa-arrow-right-from-bracket" id="logoutIconBtn" style="font-size: 0.75rem; opacity: 0.7; margin-left: 0.2rem;" title="Log out"></i>
        </div>
      `;

      const logoutIconBtn = document.getElementById('logoutIconBtn');
      if (logoutIconBtn) {
        logoutIconBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (confirm('Are you sure you want to log out?')) {
            logout();
            showGlobalToast('Logged out successfully', 'info');
          }
        });
      }
    } else {
      authArea.innerHTML = `
        <button class="nav-auth-btn" id="openAuthModalBtn">
          <i class="fa-solid fa-user-lock"></i>
          <span>Sign In</span>
        </button>
      `;

      const openBtn = document.getElementById('openAuthModalBtn');
      if (openBtn) {
        openBtn.addEventListener('click', () => openAuthModal());
      }
    }
  }

  function injectAuthModal() {
    if (document.getElementById('authModal')) return;

    const modalHtml = `
      <div class="modal-overlay" id="authModal">
        <div class="modal-content" style="max-width: 440px;">
          <div class="modal-header">
            <div>
              <span class="badge badge-primary">Account Access</span>
              <h3 class="modal-title" style="margin-top: 0.25rem;">DocBuilder Account</h3>
            </div>
            <button id="closeAuthModalBtn" class="btn btn-ghost btn-sm" title="Close">
              <i class="fa-solid fa-xmark" style="font-size: 1.25rem;"></i>
            </button>
          </div>

          <div class="modal-body">
            <div class="auth-tabs">
              <button class="auth-tab-btn active" id="tabLoginBtn">Sign In</button>
              <button class="auth-tab-btn" id="tabRegisterBtn">Create Account</button>
            </div>

            <!-- Login Form -->
            <form id="authLoginForm">
              <div class="form-group">
                <label class="form-label" for="loginEmail">Email Address</label>
                <input type="email" id="loginEmail" class="form-input" placeholder="student@rcpit.ac.in" required autocomplete="email" />
              </div>
              <div class="form-group">
                <label class="form-label" for="loginPassword">Password</label>
                <input type="password" id="loginPassword" class="form-input" placeholder="••••••••" required autocomplete="current-password" />
              </div>
              <div id="loginError" class="form-error-msg"></div>
              <button type="submit" class="btn btn-primary btn-block" style="width: 100%; margin-top: 1rem;" id="loginSubmitBtn">
                <i class="fa-solid fa-arrow-right-to-bracket"></i> Sign In to DocBuilder
              </button>
              <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 0.85rem; text-align: center;">
                Demo Credentials: <strong>rutuja@rcpit.ac.in</strong> / <strong>password123</strong>
              </p>
            </form>

            <!-- Register Form -->
            <form id="authRegisterForm" style="display: none;">
              <div class="form-group">
                <label class="form-label" for="regFullName">Full Name</label>
                <input type="text" id="regFullName" class="form-input" placeholder="Rutuja Mahajan" required />
              </div>
              <div class="form-group">
                <label class="form-label" for="regRollNo">Roll No / PRN (Optional)</label>
                <input type="text" id="regRollNo" class="form-input" placeholder="IT040 / 251109054" />
              </div>
              <div class="form-group">
                <label class="form-label" for="regEmail">Email Address</label>
                <input type="email" id="regEmail" class="form-input" placeholder="name@rcpit.ac.in" required autocomplete="email" />
              </div>
              <div class="form-group">
                <label class="form-label" for="regPassword">Password (Min. 6 chars)</label>
                <input type="password" id="regPassword" class="form-input" placeholder="••••••••" minlength="6" required autocomplete="new-password" />
              </div>
              <div id="registerError" class="form-error-msg"></div>
              <button type="submit" class="btn btn-primary btn-block" style="width: 100%; margin-top: 1rem;" id="registerSubmitBtn">
                <i class="fa-solid fa-user-plus"></i> Create Account
              </button>
            </form>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);

    // Event listeners
    const modal = document.getElementById('authModal');
    const closeBtn = document.getElementById('closeAuthModalBtn');
    const tabLogin = document.getElementById('tabLoginBtn');
    const tabRegister = document.getElementById('tabRegisterBtn');
    const formLogin = document.getElementById('authLoginForm');
    const formRegister = document.getElementById('authRegisterForm');

    closeBtn.addEventListener('click', closeAuthModal);
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeAuthModal();
    });

    tabLogin.addEventListener('click', () => {
      tabLogin.classList.add('active');
      tabRegister.classList.remove('active');
      formLogin.style.display = 'block';
      formRegister.style.display = 'none';
      document.getElementById('loginError').style.display = 'none';
    });

    tabRegister.addEventListener('click', () => {
      tabRegister.classList.add('active');
      tabLogin.classList.remove('active');
      formLogin.style.display = 'none';
      formRegister.style.display = 'block';
      document.getElementById('registerError').style.display = 'none';
    });

    // Handle Login Submit
    formLogin.addEventListener('submit', async (e) => {
      e.preventDefault();
      const errBox = document.getElementById('loginError');
      const submitBtn = document.getElementById('loginSubmitBtn');
      const email = document.getElementById('loginEmail').value.trim();
      const password = document.getElementById('loginPassword').value;

      errBox.style.display = 'none';
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Signing In...';

      try {
        await auth.login(email, password);
        closeAuthModal();
        showGlobalToast('Signed in successfully!', 'success');
      } catch (err) {
        errBox.textContent = err.message || 'Login failed. Please check credentials.';
        errBox.style.display = 'block';
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-arrow-right-to-bracket"></i> Sign In to DocBuilder';
      }
    });

    // Handle Register Submit
    formRegister.addEventListener('submit', async (e) => {
      e.preventDefault();
      const errBox = document.getElementById('registerError');
      const submitBtn = document.getElementById('registerSubmitBtn');
      const fullName = document.getElementById('regFullName').value.trim();
      const rollNo = document.getElementById('regRollNo').value.trim();
      const email = document.getElementById('regEmail').value.trim();
      const password = document.getElementById('regPassword').value;

      errBox.style.display = 'none';
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Creating Account...';

      try {
        await auth.register(fullName, email, password, rollNo);
        closeAuthModal();
        showGlobalToast(`Welcome ${fullName}! Account created.`, 'success');
      } catch (err) {
        errBox.textContent = err.message || 'Registration failed.';
        errBox.style.display = 'block';
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Create Account';
      }
    });
  }

  function openAuthModal() {
    const modal = document.getElementById('authModal');
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
      setTimeout(() => {
        const emailInput = document.getElementById('loginEmail');
        if (emailInput) emailInput.focus();
      }, 100);
    }
  }

  function closeAuthModal() {
    const modal = document.getElementById('authModal');
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  function showGlobalToast(message, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    let icon = 'fa-check-circle';
    if (type === 'danger') icon = 'fa-triangle-exclamation';
    if (type === 'warning') icon = 'fa-circle-exclamation';
    if (type === 'info') icon = 'fa-circle-info';

    toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${escapeHtml(message)}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  return {
    getToken,
    getUser,
    isAuthenticated,
    request,
    auth,
    docs,
    initAuthUI,
    openAuthModal,
    closeAuthModal,
    showGlobalToast
  };
})();

// Automatically initialize auth UI on DOM content loaded
document.addEventListener('DOMContentLoaded', () => {
  API.initAuthUI();
});
