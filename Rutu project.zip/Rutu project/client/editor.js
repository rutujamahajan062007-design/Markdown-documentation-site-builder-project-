/**
 * Markdown Documentation Site Builder - Editor Logic (Connected to API)
 * Group 20 | Semester III | RCPIT Shirpur
 */

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const markdownInput = document.getElementById('markdownInput');
  const preview = document.getElementById('preview');
  const documentTitle = document.getElementById('documentTitle');
  const saveStatusBadge = document.getElementById('saveStatusBadge');
  
  // Stats Elements
  const lineCountEl = document.getElementById('lineCount');
  const wordCountEl = document.getElementById('wordCount');
  const charCountEl = document.getElementById('charCount');

  // Action Buttons
  const saveBtn = document.getElementById('saveBtn');
  const exportHtmlBtn = document.getElementById('exportHtmlBtn');
  const downloadMdBtn = document.getElementById('downloadMdBtn');
  const clearBtn = document.getElementById('clearBtn');
  const templateBtn = document.getElementById('templateBtn');
  const revisionsBtn = document.getElementById('revisionsBtn');
  const revCountBadge = document.getElementById('revCountBadge');

  // Revisions Modal Elements
  const revisionsModal = document.getElementById('revisionsModal');
  const closeRevisionsModalBtn = document.getElementById('closeRevisionsModalBtn');
  const closeRevisionsModalActionBtn = document.getElementById('closeRevisionsModalActionBtn');
  const revModalDocTitle = document.getElementById('revModalDocTitle');
  const revisionsContainer = document.getElementById('revisionsContainer');

  // View Toggles
  const editorWorkspace = document.getElementById('editorWorkspace');
  const editorPane = document.getElementById('editorPane');
  const previewPane = document.getElementById('previewPane');
  const viewSplitBtn = document.getElementById('viewSplitBtn');
  const viewEditorBtn = document.getElementById('viewEditorBtn');
  const viewPreviewBtn = document.getElementById('viewPreviewBtn');

  // State Tracking
  let currentDocId = null;
  let currentVersion = 1;

  // Configure Marked.js
  if (typeof marked !== 'undefined') {
    marked.setOptions({
      gfm: true,
      breaks: true,
      headerIds: true,
      mangle: false
    });
  }

  // Sample College Project Documentation Template
  const sampleMarkdown = `# Markdown Documentation Site Builder
> **Semester Project-I Synopsis** &bull; Semester III (2025-26)  
> Department of Information Technology &bull; **Group 20**  
> **R. C. Patel Institute of Technology, Shirpur**

---

## 1. Project Overview
The **Markdown Documentation Site Builder** simplifies creating structured technical documentation websites. Instead of authoring intricate HTML by hand, developers and students write simple **Markdown**, which our platform compiles into responsive, beautifully styled web pages.

### Key Objectives:
- [x] High-performance split-screen editing
- [x] Live Markdown-to-HTML rendering with \`marked.js\`
- [x] Standalone HTML export ready for web distribution
- [x] Clean, distraction-free Notion-style interface
- [x] Backend API integration with Node.js & MySQL

---

## 2. Project Team (Group 20)

| Roll No. | PRN | Student Name | Role |
| :--- | :--- | :--- | :--- |
| **IT040** | \`251109054\` | Rutuja Mahendrakumar Mahajan | Team Lead & Frontend |
| **IT030** | \`251109034\` | Tanushri Nitin Bhadhane | UI / UX Design & Marked.js |
| **IT033** | \`251109045\` | Gayatri Vijaysing Thakur | Documentation & Research |
| **IT059** | \`251109076\` | Bhumika Chetan Patil | Testing & Export Engine |

**Project Guide:** Prof. A.Z. Ansari

---

## 3. System Architecture & Tech Stack

\`\`\`javascript
// Client-side Live Markdown Parsing Pipeline
function renderDocumentation(markdownSource) {
  const cleanHtml = marked.parse(markdownSource);
  document.getElementById('preview').innerHTML = cleanHtml;
  updateMetadataCounts();
}
\`\`\`

### Technology Highlights:
1. **HTML5**: Semantic document structure.
2. **CSS3**: Responsive flexbox/grid layout and custom typography.
3. **JavaScript**: Dynamic split-screen reactivity and file blob generators.
4. **Node.js & MySQL**: Secure user credentials, document storage, and revisions history.

---

## 4. Quick Usage Instructions
1. Edit any text in the **Markdown Source** left pane.
2. Observe instantaneous HTML updates on the **Live HTML Preview** right pane.
3. Click **Export HTML** on the top toolbar to download a self-contained, publication-ready web page!

> *“Simplicity is prerequisite for reliability.”* &mdash; Edsger W. Dijkstra
`;

  // Initialize Content
  async function initEditor() {
    // 1. Check URL query parameters for ?id=...
    const urlParams = new URLSearchParams(window.location.search);
    const docIdParam = urlParams.get('id');

    // 2. Check sessionStorage bridge from my-docs.html
    const editDocData = sessionStorage.getItem('docbuilder_edit_target');
    const autoSavedContent = localStorage.getItem('docbuilder_active_content');
    const autoSavedTitle = localStorage.getItem('docbuilder_active_title');

    if (docIdParam && API.isAuthenticated()) {
      try {
        saveStatusBadge.className = 'badge badge-primary';
        saveStatusBadge.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Loading...';
        const res = await API.docs.getById(docIdParam);
        if (res.document) {
          currentDocId = res.document.id;
          currentVersion = res.document.currentVersion || 1;
          markdownInput.value = res.document.content || '';
          documentTitle.value = res.document.title ? `${res.document.title}.md` : 'Document.md';
          updateRevisionUI(currentVersion);
          showToast(`Loaded "${res.document.title}" (v${currentVersion})`, 'success');
          renderMarkdown();
          return;
        }
      } catch (err) {
        console.warn('[Editor] Failed to fetch doc from API:', err.message);
      }
    }

    if (editDocData) {
      try {
        const parsedDoc = JSON.parse(editDocData);
        currentDocId = parsedDoc.id || null;
        markdownInput.value = parsedDoc.content || '';
        documentTitle.value = parsedDoc.title ? `${parsedDoc.title}.md` : 'Document.md';
        sessionStorage.removeItem('docbuilder_edit_target');

        if (currentDocId && API.isAuthenticated()) {
          checkAndLoadRevisions(currentDocId);
        }

        showToast(`Loaded "${parsedDoc.title}"`, 'success');
      } catch (e) {
        markdownInput.value = sampleMarkdown;
      }
    } else if (autoSavedContent) {
      markdownInput.value = autoSavedContent;
      if (autoSavedTitle) documentTitle.value = autoSavedTitle;
    } else {
      markdownInput.value = sampleMarkdown;
    }

    renderMarkdown();
  }

  // Render Markdown to Preview
  function renderMarkdown() {
    const rawText = markdownInput.value;
    
    if (typeof marked !== 'undefined') {
      preview.innerHTML = marked.parse(rawText);
    } else {
      preview.innerText = rawText;
    }

    updateStats(rawText);

    // Auto-save local draft
    localStorage.setItem('docbuilder_active_content', rawText);
    localStorage.setItem('docbuilder_active_title', documentTitle.value);
  }

  // Update Line, Word, and Character Counts
  function updateStats(text) {
    const lines = text.length === 0 ? 0 : text.split('\n').length;
    const words = text.trim() === '' ? 0 : text.trim().split(/\s+/).filter(Boolean).length;
    const chars = text.length;

    lineCountEl.innerHTML = `<i class="fa-solid fa-bars"></i> ${lines} Lines`;
    wordCountEl.innerHTML = `<i class="fa-solid fa-font"></i> ${words} Words`;
    charCountEl.innerHTML = `<i class="fa-solid fa-calculator"></i> ${chars} Chars`;
  }

  // Event: Input Typing
  markdownInput.addEventListener('input', () => {
    renderMarkdown();
    indicateEditing();
  });

  documentTitle.addEventListener('input', () => {
    localStorage.setItem('docbuilder_active_title', documentTitle.value);
    indicateEditing();
  });

  let editTimeout;
  function indicateEditing() {
    saveStatusBadge.className = 'badge badge-primary';
    saveStatusBadge.innerHTML = '<i class="fa-solid fa-pen"></i> Editing...';
    clearTimeout(editTimeout);
    editTimeout = setTimeout(() => {
      saveStatusBadge.className = 'badge badge-success';
      saveStatusBadge.innerHTML = '<i class="fa-solid fa-circle-check"></i> Draft Saved';
    }, 800);
  }

  // Tab Key Support in Textarea
  markdownInput.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = markdownInput.selectionStart;
      const end = markdownInput.selectionEnd;

      markdownInput.value = markdownInput.value.substring(0, start) + '  ' + markdownInput.value.substring(end);
      markdownInput.selectionStart = markdownInput.selectionEnd = start + 2;
      renderMarkdown();
    }
  });

  // View Mode Controls
  function setViewMode(mode) {
    [viewSplitBtn, viewEditorBtn, viewPreviewBtn].forEach(btn => btn.classList.remove('active'));

    if (mode === 'split') {
      viewSplitBtn.classList.add('active');
      editorPane.style.display = 'flex';
      editorPane.style.flex = '1';
      previewPane.style.display = 'flex';
      previewPane.style.flex = '1';
    } else if (mode === 'editor') {
      viewEditorBtn.classList.add('active');
      editorPane.style.display = 'flex';
      editorPane.style.flex = '1';
      previewPane.style.display = 'none';
    } else if (mode === 'preview') {
      viewPreviewBtn.classList.add('active');
      editorPane.style.display = 'none';
      previewPane.style.display = 'flex';
      previewPane.style.flex = '1';
    }
  }

  viewSplitBtn.addEventListener('click', () => setViewMode('split'));
  viewEditorBtn.addEventListener('click', () => setViewMode('editor'));
  viewPreviewBtn.addEventListener('click', () => setViewMode('preview'));

  // Toolbar Actions Helper
  function insertFormatting(prefix, suffix = '', defaultPlaceholder = '') {
    const start = markdownInput.selectionStart;
    const end = markdownInput.selectionEnd;
    const selected = markdownInput.value.substring(start, end);
    const contentToInsert = selected || defaultPlaceholder;
    
    const replacement = `${prefix}${contentToInsert}${suffix}`;
    markdownInput.setRangeText(replacement, start, end, 'select');
    markdownInput.focus();
    renderMarkdown();
  }

  // Formatting Toolbar Listeners
  document.getElementById('formatToolbar').addEventListener('click', (e) => {
    const btn = e.target.closest('.toolbar-btn');
    if (!btn) return;

    const action = btn.getAttribute('data-action');
    switch (action) {
      case 'h1': insertFormatting('# ', '', 'Heading 1'); break;
      case 'h2': insertFormatting('## ', '', 'Heading 2'); break;
      case 'h3': insertFormatting('### ', '', 'Heading 3'); break;
      case 'bold': insertFormatting('**', '**', 'bold text'); break;
      case 'italic': insertFormatting('*', '*', 'italic text'); break;
      case 'strikethrough': insertFormatting('~~', '~~', 'strikethrough'); break;
      case 'code': insertFormatting('`', '`', 'code'); break;
      case 'codeblock': insertFormatting('```javascript\n', '\n```', '// Your code here'); break;
      case 'quote': insertFormatting('> ', '', 'Quoted text / callout'); break;
      case 'ul': insertFormatting('- ', '', 'List item'); break;
      case 'ol': insertFormatting('1. ', '', 'First item'); break;
      case 'task': insertFormatting('- [ ] ', '', 'Task to accomplish'); break;
      case 'table': 
        insertFormatting(
          '| Feature | Description | Status |\n| :--- | :--- | :--- |\n| Live Preview | Real-time HTML | Completed |\n| File Export | Standalone HTML | Completed |\n'
        ); 
        break;
      case 'link': insertFormatting('[', '](https://example.com)', 'Link Text'); break;
      case 'image': insertFormatting('![', '](https://picsum.photos/600/300)', 'Image Alt Text'); break;
      case 'hr': insertFormatting('\n---\n', ''); break;
    }
  });

  // Action: Load Sample Template
  templateBtn.addEventListener('click', () => {
    if (confirm('Load sample project documentation template? Unsaved changes will be replaced.')) {
      markdownInput.value = sampleMarkdown;
      documentTitle.value = 'Markdown_Documentation_Synopsis.md';
      currentDocId = null;
      if (revisionsBtn) revisionsBtn.style.display = 'none';
      renderMarkdown();
      showToast('Sample template loaded!', 'success');
    }
  });

  // Action: Clear Editor
  clearBtn.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear the entire editor?')) {
      markdownInput.value = '';
      currentDocId = null;
      if (revisionsBtn) revisionsBtn.style.display = 'none';
      renderMarkdown();
      showToast('Editor cleared', 'warning');
    }
  });

  // Action: Save Document (API + Database with LocalStorage Fallback)
  saveBtn.addEventListener('click', async () => {
    const rawTitle = documentTitle.value.trim().replace(/\.md$/i, '') || 'Untitled Document';
    const content = markdownInput.value;
    const now = new Date();
    const dateFormatted = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    saveStatusBadge.className = 'badge badge-primary';
    saveStatusBadge.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

    // Check if user is authenticated with backend
    if (API.isAuthenticated()) {
      try {
        if (currentDocId && !isNaN(parseInt(currentDocId, 10))) {
          // Update existing document in MySQL
          const res = await API.docs.update(currentDocId, {
            title: rawTitle,
            content: content,
            changeSummary: `Manual save from editor`
          });
          currentVersion = res.document.version;
          updateRevisionUI(currentVersion);
          showToast(`Saved "${rawTitle}" to MySQL (v${currentVersion})!`, 'success');
        } else {
          // Create new document in MySQL
          const res = await API.docs.create({
            title: rawTitle,
            content: content,
            category: 'General'
          });
          currentDocId = res.document.id;
          currentVersion = res.document.version || 1;
          updateRevisionUI(currentVersion);
          window.history.replaceState({}, '', `/editor?id=${currentDocId}`);
          showToast(`Created "${rawTitle}" in MySQL database!`, 'success');
        }

        saveStatusBadge.className = 'badge badge-success';
        saveStatusBadge.innerHTML = `<i class="fa-solid fa-cloud-check"></i> Saved (v${currentVersion})`;
        return;
      } catch (err) {
        console.error('[Editor] Backend save error:', err);
        showToast(`Cloud save failed (${err.message}). Saved locally.`, 'warning');
      }
    }

    // LocalStorage Fallback (Offline / Unauthenticated)
    saveToLocalStorage(rawTitle, content, dateFormatted);
    saveStatusBadge.className = 'badge badge-success';
    saveStatusBadge.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Saved Locally';
    showToast(`Saved "${rawTitle}" to local storage. Sign in to sync with MySQL!`, 'info');
  });

  function saveToLocalStorage(title, content, dateFormatted) {
    const savedDocsKey = 'docbuilder_custom_docs';
    let docs = [];
    try {
      docs = JSON.parse(localStorage.getItem(savedDocsKey)) || [];
    } catch (e) {
      docs = [];
    }

    const existingIndex = docs.findIndex(d => d.title.toLowerCase() === title.toLowerCase());
    const docData = {
      id: existingIndex >= 0 ? docs[existingIndex].id : 'doc_' + Date.now(),
      title: title,
      content: content,
      date: dateFormatted,
      words: content.trim() === '' ? 0 : content.trim().split(/\s+/).filter(Boolean).length,
      category: 'User Saved'
    };

    if (existingIndex >= 0) {
      docs[existingIndex] = docData;
    } else {
      docs.unshift(docData);
    }

    localStorage.setItem(savedDocsKey, JSON.stringify(docs));
    localStorage.setItem('docbuilder_active_content', content);
    localStorage.setItem('docbuilder_active_title', documentTitle.value);
  }

  function updateRevisionUI(version) {
    if (revisionsBtn && revCountBadge && currentDocId) {
      revisionsBtn.style.display = 'inline-flex';
      revCountBadge.textContent = `v${version}`;
    }
  }

  async function checkAndLoadRevisions(docId) {
    try {
      const res = await API.docs.getRevisions(docId);
      if (res.revisions && res.revisions.length > 0) {
        currentVersion = res.revisions[0].version;
        updateRevisionUI(currentVersion);
      }
    } catch (e) {
      // Ignore
    }
  }

  // Revisions Modal Handler
  if (revisionsBtn) {
    revisionsBtn.addEventListener('click', async () => {
      if (!currentDocId) return;
      revModalDocTitle.textContent = documentTitle.value.replace(/\.md$/i, '') + ' - Version History';
      revisionsModal.classList.add('active');
      document.body.style.overflow = 'hidden';

      revisionsContainer.innerHTML = `
        <div style="text-align: center; padding: 2rem; color: var(--text-muted);">
          <i class="fa-solid fa-spinner fa-spin"></i> Fetching revisions from MySQL...
        </div>
      `;

      try {
        const res = await API.docs.getRevisions(currentDocId);
        if (!res.revisions || res.revisions.length === 0) {
          revisionsContainer.innerHTML = '<p style="text-align: center; color: var(--text-muted);">No revisions recorded yet.</p>';
          return;
        }

        revisionsContainer.innerHTML = res.revisions.map(rev => `
          <div class="revision-item">
            <div class="revision-meta">
              <div>
                <span class="revision-badge">v${rev.version}</span>
                <strong style="margin-left: 0.35rem; font-size: 0.9rem;">${escapeHtml(rev.summary)}</strong>
              </div>
              <small style="color: var(--text-muted); font-size: 0.78rem;">
                <i class="fa-regular fa-calendar"></i> ${escapeHtml(rev.date)} &bull; ${rev.words} words
              </small>
            </div>
            <div>
              <button class="btn btn-secondary btn-sm restore-rev-btn" data-version="${rev.version}" title="Restore this version">
                <i class="fa-solid fa-rotate-left"></i> Restore
              </button>
            </div>
          </div>
        `).join('');

        // Attach restore handlers
        revisionsContainer.querySelectorAll('.restore-rev-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const v = btn.getAttribute('data-version');
            if (confirm(`Roll back document to revision v${v}?`)) {
              try {
                btn.disabled = true;
                const restRes = await API.docs.restoreRevision(currentDocId, v);
                markdownInput.value = restRes.document.content;
                currentVersion = restRes.document.version;
                updateRevisionUI(currentVersion);
                renderMarkdown();
                closeRevisionsModal();
                showToast(restRes.message || `Restored to v${v}`, 'success');
              } catch (err) {
                showToast(`Restore failed: ${err.message}`, 'danger');
              }
            }
          });
        });
      } catch (err) {
        revisionsContainer.innerHTML = `<p style="color: var(--danger); text-align: center;">Failed to load revisions: ${escapeHtml(err.message)}</p>`;
      }
    });
  }

  function closeRevisionsModal() {
    if (revisionsModal) {
      revisionsModal.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (closeRevisionsModalBtn) closeRevisionsModalBtn.addEventListener('click', closeRevisionsModal);
  if (closeRevisionsModalActionBtn) closeRevisionsModalActionBtn.addEventListener('click', closeRevisionsModal);
  if (revisionsModal) {
    revisionsModal.addEventListener('click', (e) => {
      if (e.target === revisionsModal) closeRevisionsModal();
    });
  }

  // Action: Export Standalone HTML
  exportHtmlBtn.addEventListener('click', () => {
    const rawTitle = documentTitle.value.trim().replace(/\.md$/i, '') || 'Documentation';
    const htmlBody = preview.innerHTML;

    // Build self-contained HTML page with embedded Notion styling
    const fullHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(rawTitle)}</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background-color: #ffffff;
      color: #0f172a;
      line-height: 1.75;
      padding: 3rem 1.5rem;
      max-width: 880px;
      margin: 0 auto;
    }
    header.doc-meta-banner {
      border-bottom: 2px solid #e2e8f0;
      padding-bottom: 1.5rem;
      margin-bottom: 2.5rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 1rem;
      color: #64748b;
      font-size: 0.85rem;
    }
    h1, h2, h3, h4 { color: #0f172a; font-weight: 700; margin-top: 1.85rem; margin-bottom: 0.85rem; }
    h1 { font-size: 2.2rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 0.5rem; margin-top: 0; }
    h2 { font-size: 1.5rem; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.35rem; }
    p { margin-bottom: 1.1rem; }
    a { color: #4f46e5; text-decoration: underline; }
    blockquote {
      border-left: 4px solid #4f46e5;
      padding: 0.85rem 1.25rem;
      margin: 1.25rem 0;
      background-color: #f8fafc;
      border-radius: 0 6px 6px 0;
      color: #334155;
    }
    code {
      font-family: 'JetBrains Mono', monospace;
      font-size: 0.9em;
      background-color: #f1f5f9;
      padding: 0.2em 0.4em;
      border-radius: 4px;
      border: 1px solid #e2e8f0;
    }
    pre {
      background-color: #0f172a;
      color: #e2e8f0;
      border-radius: 8px;
      padding: 1.2rem;
      overflow-x: auto;
      margin: 1.25rem 0;
    }
    pre code { background: transparent; border: none; padding: 0; color: inherit; }
    table { width: 100%; border-collapse: collapse; margin: 1.5rem 0; }
    th, td { padding: 0.75rem 1rem; border: 1px solid #e2e8f0; text-align: left; }
    th { background-color: #f8fafc; font-weight: 600; }
    tr:nth-child(even) { background-color: #fcfcfd; }
    hr { height: 1px; background-color: #e2e8f0; border: none; margin: 2rem 0; }
    ul, ol { padding-left: 1.75rem; margin-bottom: 1.1rem; }
    li { margin-bottom: 0.4rem; }
    footer.doc-export-footer {
      margin-top: 4rem;
      padding-top: 1.5rem;
      border-top: 1px solid #e2e8f0;
      text-align: center;
      font-size: 0.8rem;
      color: #94a3b8;
    }
  </style>
</head>
<body>
  <header class="doc-meta-banner">
    <div><strong>Generated via:</strong> Markdown Documentation Site Builder</div>
    <div>Group 20 &bull; RCPIT Shirpur &bull; ${new Date().toLocaleDateString()}</div>
  </header>

  <article>
    ${htmlBody}
  </article>

  <footer class="doc-export-footer">
    Documentation generated automatically by Markdown Documentation Site Builder &bull; Dept of IT, RCPIT Shirpur
  </footer>
</body>
</html>`;

    downloadFile(fullHtml, `${rawTitle}.html`, 'text/html');
    showToast(`Exported "${rawTitle}.html"!`, 'success');
  });

  // Action: Download Markdown File
  downloadMdBtn.addEventListener('click', () => {
    const rawTitle = documentTitle.value.trim().replace(/\.md$/i, '') || 'Document';
    const content = markdownInput.value;
    downloadFile(content, `${rawTitle}.md`, 'text/markdown');
    showToast(`Downloaded "${rawTitle}.md"!`, 'success');
  });

  // Helper: Trigger File Download
  function downloadFile(content, fileName, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 100);
  }

  // Toast Notifications
  function showToast(message, type = 'success') {
    if (typeof API !== 'undefined' && API.showGlobalToast) {
      API.showGlobalToast(message, type);
      return;
    }

    const toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let iconClass = 'fa-check-circle';
    if (type === 'danger') iconClass = 'fa-triangle-exclamation';
    if (type === 'warning') iconClass = 'fa-circle-exclamation';

    toast.innerHTML = `<i class="fa-solid ${iconClass}"></i> <span>${escapeHtml(message)}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  function escapeHtml(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // Re-sync on auth state changes
  window.addEventListener('auth-changed', () => {
    if (currentDocId && API.isAuthenticated()) {
      checkAndLoadRevisions(currentDocId);
    }
  });

  // Boot
  initEditor();
});
