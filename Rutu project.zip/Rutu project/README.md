# Markdown Documentation Site Builder

**Academic Project-I | Semester III [2025-26]**  
*Department of Information Technology, R. C. Patel Institute of Technology, Shirpur (Autonomous)*  
**Group No. 20** &bull; **Project Guide:** Prof. A.Z. Ansari  

---

## 📖 Overview

The **Markdown Documentation Site Builder** is a modern, high-performance web platform that empowers developers, students, and technical writers to create elegant, publication-ready documentation websites. Users write clean, standard-compliant **Markdown**, and the system produces live-rendered HTML alongside standalone, styled exportable files.

This repository connects the existing frontend UI with a robust **Node.js + Express + MySQL 8.0** backend with **JWT authentication** and **automatic document revision history**.

---

## 🛠️ Technology Stack

* **Frontend**: HTML5, CSS3 (Notion-inspired theme), Vanilla JavaScript (ES6+), FontAwesome 6, `marked.js` (via CDN).
* **Backend**: Node.js (`>= v18`), Express.js 4.
* **Database**: MySQL Server 8.0 (InnoDB with connection pooling via `mysql2/promise`).
* **Authentication**: JSON Web Tokens (`jsonwebtoken`) with `bcryptjs` password hashing.
* **Storage Engine**: MySQL database for authenticated cloud persistence, with local draft auto-saving fallback.

---

## 📁 Project Directory Structure

```text
Rutu project/
├── client/                     # Preserved Frontend UI
│   ├── index.html              # Landing page, synopsis, and team details
│   ├── editor.html             # Split-screen live Markdown workstation
│   ├── my-docs.html            # Saved documents dashboard & search catalog
│   ├── style.css               # Notion-inspired responsive design system
│   ├── editor.js               # Editor mechanics, live preview, revisions & exports
│   ├── docs.js                 # Document dashboard, filter pills & preview modal
│   └── js/
│       └── api.js              # Centralized API fetch helper & JWT session manager
├── server/                     # Node.js + Express Backend
│   ├── config/
│   │   └── db.js               # MySQL 8.0 connection pool & auto-table initializer
│   ├── controllers/
│   │   ├── authController.js   # User registration, login, and profile fetching
│   │   └── docController.js    # Document CRUD, auto-revision tracking, and rollback
│   ├── middleware/
│   │   ├── authMiddleware.js   # JWT Bearer token authentication guard
│   │   └── (error handling)
│   ├── routes/
│   │   ├── authRoutes.js       # /api/auth routes
│   │   └── docRoutes.js        # /api/docs routes
│   └── server.js               # Express application entrypoint & static host
├── database/
│   └── schema.sql              # MySQL DDL migration script & sample seed data
├── tests/
│   └── test_suite.js           # Automated integration test suite
├── .env.example                # Environment variables template
├── .env                        # Local environment configuration
├── .gitignore
├── package.json
└── README.md
```

---

## ⚙️ Quickstart & Setup Guide

### 1. Prerequisites
Ensure you have installed:
* **Node.js** (`node -v` >= 18.0.0)
* **MySQL Server 8.0** running as a local service (`MySQL80`)

### 2. Configure Environment Variables
Open the `.env` file in the project root and enter your MySQL root password:

```env
# Server Configuration
PORT=5000
NODE_ENV=development

# MySQL Database Configuration
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_actual_mysql_password_here
DB_NAME=docbuilder_db

# JWT Secret & Token Expiration
JWT_SECRET=docbuilder_jwt_secret_rcpit_group20_2026
JWT_EXPIRES_IN=7d
```

### 3. Initialize the MySQL Database
You can import the schema directly into MySQL using your command line:

```powershell
& "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p < database\schema.sql
```
*(When prompted, type your MySQL root password).*

> **Auto-Init Feature**: When you start the server with valid credentials, `server/config/db.js` will also automatically verify, create the database `docbuilder_db`, initialize the tables, and seed the demo account if not already present.

### 4. Install Dependencies
```powershell
npm.cmd install
```

### 5. Launch the Server
```powershell
npm.cmd start
```
Or with auto-restart on file changes:
```powershell
npm.cmd run dev
```

Open your browser and navigate to:
* **Landing Page**: [http://localhost:5000/](http://localhost:5000/)
* **Live Editor**: [http://localhost:5000/editor](http://localhost:5000/editor)
* **Saved Documents**: [http://localhost:5000/my-docs](http://localhost:5000/my-docs)
* **API Health**: [http://localhost:5000/api/health](http://localhost:5000/api/health)

---

## 🔑 Authentication & Demo Account

The database seeds a default demo account on first run:

* **Email**: `rutuja@rcpit.ac.in`
* **Password**: `password123`

You can also click **Sign In &rarr; Create Account** in the top navigation bar of any page to register a new user profile with your own credentials and roll number.

---

## 📡 REST API Reference

### Authentication (`/api/auth`)
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/register` | Register new user account | Public |
| `POST` | `/api/auth/login` | Authenticate user & receive JWT token | Public |
| `GET` | `/api/auth/me` | Fetch authenticated user profile | Private (`Bearer <token>`) |

### Documents (`/api/docs`)
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/docs` | List user documents (supports `?category=` and `?search=`) | Private (`Bearer <token>`) |
| `GET` | `/api/docs/:id` | Retrieve single document metadata & markdown | Public / Private |
| `POST` | `/api/docs` | Create new document (creates revision #1) | Private (`Bearer <token>`) |
| `PUT` | `/api/docs/:id` | Update document (increments revision number) | Private (`Bearer <token>`) |
| `DELETE`| `/api/docs/:id` | Delete document (cascades to revisions) | Private (`Bearer <token>`) |

### Document Revisions (`/api/docs/:id/revisions`)
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/docs/:id/revisions` | View version history for a document | Private (`Bearer <token>`) |
| `POST` | `/api/docs/:id/revisions/:version/restore` | Roll back document to previous revision | Private (`Bearer <token>`) |

---

## 🧪 Testing Guide

### Automated API & Asset Verification
Run the built-in test suite:
```powershell
node tests/test_suite.js
```

### Manual End-to-End Workflow Testing
1. **User Sign In**:
   - Click **Sign In** in the top header on any page.
   - Enter `rutuja@rcpit.ac.in` and `password123`.
   - Notice the header updates to show the user avatar badge (`RM Rutuja`).
2. **Document Creation**:
   - Navigate to `/editor`.
   - Rename the document title to `My_First_Guide.md`.
   - Write Markdown on the left pane and observe live rendering on the right pane.
   - Click the **Save** button. The badge transitions to `Saved (v1)` and syncs to MySQL.
3. **Revisions & Version History**:
   - Edit some text in the editor and click **Save** again. The badge updates to `Saved (v2)`.
   - Click the **History** button on the top toolbar.
   - A modal displays all historical versions (v1, v2, timestamp, words).
   - Click **Restore** on v1 to roll back the document content.
4. **Export Engine**:
   - Click **Export HTML** to download a self-contained, beautifully styled HTML file.
   - Click **.md** on the formatting toolbar to download the raw Markdown file.
5. **Dashboard Management**:
   - Navigate to `/my-docs`.
   - Use the search bar to filter by title or keyword.
   - Click the category filter pills (`API`, `Database`, `Synopsis`).
   - Click **View** to open the quick preview modal.
   - Click **Edit** to open any document directly in the split-screen editor.
   - Click **Delete** to delete a document from the MySQL database.
6. **Offline Fallback**:
   - If not signed in, the editor and documents dashboard automatically store drafts in `localStorage` so no user work is ever lost!
