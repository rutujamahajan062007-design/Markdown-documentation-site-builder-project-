const { getPool } = require('../config/db');

/**
 * Helper to strip markdown symbols and generate a clean excerpt
 */
function generateExcerpt(markdown, maxLength = 160) {
  if (!markdown) return '';
  const clean = markdown
    .replace(/^#+\s+/gm, '') // headings
    .replace(/(\*\*|__)(.*?)\1/g, '$2') // bold
    .replace(/(\*|_)(.*?)\1/g, '$2') // italic
    .replace(/`{1,3}(.*?)`{1,3}/g, '$1') // code
    .replace(/\[(.*?)\]\(.*?\)/g, '$1') // links
    .replace(/!\[(.*?)\]\(.*?\)/g, '') // images
    .replace(/>\s+/g, '') // blockquotes
    .replace(/[-*+]\s+/g, '') // lists
    .replace(/\n+/g, ' ')
    .trim();
  return clean.length > maxLength ? clean.substring(0, maxLength) + '...' : clean;
}

/**
 * Helper to count words
 */
function countWords(text) {
  if (!text) return 0;
  return text.trim().split(/\s+/).filter(Boolean).length;
}

/**
 * Helper to format date string like "Sep 05, 2026"
 */
function formatDate(dateObj) {
  const d = new Date(dateObj);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

/**
 * List documents for authenticated user
 * GET /api/docs
 */
async function getDocuments(req, res) {
  try {
    const db = getPool();
    const userId = req.user.id;
    const { category, search } = req.query;

    let query = 'SELECT id, user_id, title, category, content, excerpt, words, created_at, updated_at FROM documents WHERE user_id = ?';
    const params = [userId];

    if (category && category !== 'all') {
      query += ' AND LOWER(category) = LOWER(?)';
      params.push(category);
    }

    if (search && search.trim() !== '') {
      query += ' AND (LOWER(title) LIKE LOWER(?) OR LOWER(excerpt) LIKE LOWER(?) OR LOWER(category) LIKE LOWER(?))';
      const term = `%${search.trim()}%`;
      params.push(term, term, term);
    }

    query += ' ORDER BY updated_at DESC';

    const [rows] = await db.query(query, params);

    const formattedDocs = rows.map(doc => ({
      id: String(doc.id),
      title: doc.title,
      category: doc.category,
      content: doc.content,
      excerpt: doc.excerpt || generateExcerpt(doc.content),
      words: doc.words || countWords(doc.content),
      date: formatDate(doc.updated_at || doc.created_at),
      updatedAt: doc.updated_at,
      createdAt: doc.created_at
    }));

    return res.json({
      success: true,
      count: formattedDocs.length,
      documents: formattedDocs
    });
  } catch (err) {
    console.error('[GetDocuments Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve documents: ' + err.message
    });
  }
}

/**
 * Get single document by ID
 * GET /api/docs/:id
 */
async function getDocumentById(req, res) {
  try {
    const db = getPool();
    const docId = req.params.id;
    const userId = req.user ? req.user.id : null;

    const [rows] = await db.query(
      'SELECT id, user_id, title, category, content, excerpt, words, is_public, created_at, updated_at FROM documents WHERE id = ?',
      [docId]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Document not found.'
      });
    }

    const doc = rows[0];

    // Check ownership or public visibility
    if (doc.user_id !== userId && !doc.is_public) {
      return res.status(403).json({
        success: false,
        message: 'Access denied. You do not own this document.'
      });
    }

    // Get current revision count
    const [revCount] = await db.query(
      'SELECT COUNT(*) AS totalRevisions, MAX(version_number) AS currentVersion FROM document_revisions WHERE document_id = ?',
      [docId]
    );

    return res.json({
      success: true,
      document: {
        id: String(doc.id),
        userId: doc.user_id,
        title: doc.title,
        category: doc.category,
        content: doc.content,
        excerpt: doc.excerpt || generateExcerpt(doc.content),
        words: doc.words,
        isPublic: !!doc.is_public,
        date: formatDate(doc.updated_at || doc.created_at),
        currentVersion: revCount[0].currentVersion || 1,
        totalRevisions: revCount[0].totalRevisions || 1,
        updatedAt: doc.updated_at,
        createdAt: doc.created_at
      }
    });
  } catch (err) {
    console.error('[GetDocumentById Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve document: ' + err.message
    });
  }
}

/**
 * Create a new document
 * POST /api/docs
 */
async function createDocument(req, res) {
  try {
    const db = getPool();
    const userId = req.user.id;
    const { title, content, category, excerpt } = req.body;

    const cleanTitle = (title || 'Untitled Document').trim().replace(/\.md$/i, '');
    const cleanContent = content || '';
    const cleanCategory = (category || 'General').trim();
    const words = countWords(cleanContent);
    const cleanExcerpt = excerpt || generateExcerpt(cleanContent);

    // Insert Document
    const [docResult] = await db.query(
      'INSERT INTO documents (user_id, title, category, content, excerpt, words) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, cleanTitle, cleanCategory, cleanContent, cleanExcerpt, words]
    );

    const docId = docResult.insertId;

    // Create Initial Revision (v1)
    await db.query(
      'INSERT INTO document_revisions (document_id, user_id, version_number, title, content, words, change_summary) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [docId, userId, 1, cleanTitle, cleanContent, words, 'Initial document creation']
    );

    return res.status(201).json({
      success: true,
      message: `Document "${cleanTitle}" created successfully.`,
      document: {
        id: String(docId),
        title: cleanTitle,
        category: cleanCategory,
        content: cleanContent,
        excerpt: cleanExcerpt,
        words: words,
        version: 1,
        date: formatDate(new Date())
      }
    });
  } catch (err) {
    console.error('[CreateDocument Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to create document: ' + err.message
    });
  }
}

/**
 * Update an existing document and auto-record a revision
 * PUT /api/docs/:id
 */
async function updateDocument(req, res) {
  try {
    const db = getPool();
    const userId = req.user.id;
    const docId = req.params.id;
    const { title, content, category, excerpt, changeSummary } = req.body;

    // Verify ownership
    const [existing] = await db.query(
      'SELECT id, title, content, category, excerpt, words FROM documents WHERE id = ? AND user_id = ?',
      [docId, userId]
    );

    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Document not found or access denied.'
      });
    }

    const currentDoc = existing[0];
    const newTitle = title !== undefined ? title.trim().replace(/\.md$/i, '') : currentDoc.title;
    const newContent = content !== undefined ? content : currentDoc.content;
    const newCategory = category !== undefined ? category.trim() : currentDoc.category;
    const words = countWords(newContent);
    const newExcerpt = excerpt !== undefined ? excerpt : generateExcerpt(newContent);

    // Get current max version number
    const [revRows] = await db.query(
      'SELECT COALESCE(MAX(version_number), 0) AS maxVersion FROM document_revisions WHERE document_id = ?',
      [docId]
    );
    const nextVersion = (revRows[0].maxVersion || 0) + 1;

    // Update document record
    await db.query(
      'UPDATE documents SET title = ?, category = ?, content = ?, excerpt = ?, words = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [newTitle, newCategory, newContent, newExcerpt, words, docId]
    );

    // Record new revision
    const summary = changeSummary || `Revision ${nextVersion} saved`;
    await db.query(
      'INSERT INTO document_revisions (document_id, user_id, version_number, title, content, words, change_summary) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [docId, userId, nextVersion, newTitle, newContent, words, summary]
    );

    return res.json({
      success: true,
      message: `Document "${newTitle}" saved successfully (v${nextVersion}).`,
      document: {
        id: String(docId),
        title: newTitle,
        category: newCategory,
        content: newContent,
        excerpt: newExcerpt,
        words: words,
        version: nextVersion,
        date: formatDate(new Date())
      }
    });
  } catch (err) {
    console.error('[UpdateDocument Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to update document: ' + err.message
    });
  }
}

/**
 * Delete a document
 * DELETE /api/docs/:id
 */
async function deleteDocument(req, res) {
  try {
    const db = getPool();
    const userId = req.user.id;
    const docId = req.params.id;

    const [existing] = await db.query(
      'SELECT id, title FROM documents WHERE id = ? AND user_id = ?',
      [docId, userId]
    );

    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Document not found or access denied.'
      });
    }

    const title = existing[0].title;

    // Delete document (cascade removes revisions)
    await db.query('DELETE FROM documents WHERE id = ? AND user_id = ?', [docId, userId]);

    return res.json({
      success: true,
      message: `Document "${title}" deleted successfully.`
    });
  } catch (err) {
    console.error('[DeleteDocument Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to delete document: ' + err.message
    });
  }
}

/**
 * Get revision history for a document
 * GET /api/docs/:id/revisions
 */
async function getRevisions(req, res) {
  try {
    const db = getPool();
    const userId = req.user.id;
    const docId = req.params.id;

    // Check ownership
    const [docs] = await db.query('SELECT id, title FROM documents WHERE id = ? AND user_id = ?', [docId, userId]);
    if (docs.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Document not found or access denied.'
      });
    }

    const [revisions] = await db.query(
      'SELECT id, version_number, title, words, change_summary, created_at FROM document_revisions WHERE document_id = ? ORDER BY version_number DESC',
      [docId]
    );

    const formatted = revisions.map(r => ({
      id: r.id,
      version: r.version_number,
      title: r.title,
      words: r.words,
      summary: r.change_summary,
      date: formatDate(r.created_at),
      createdAt: r.created_at
    }));

    return res.json({
      success: true,
      documentId: docId,
      documentTitle: docs[0].title,
      revisions: formatted
    });
  } catch (err) {
    console.error('[GetRevisions Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to get revisions: ' + err.message
    });
  }
}

/**
 * Restore a previous revision
 * POST /api/docs/:id/revisions/:version/restore
 */
async function restoreRevision(req, res) {
  try {
    const db = getPool();
    const userId = req.user.id;
    const docId = req.params.id;
    const versionNumber = parseInt(req.params.version, 10);

    // Verify ownership
    const [docs] = await db.query('SELECT id, title FROM documents WHERE id = ? AND user_id = ?', [docId, userId]);
    if (docs.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Document not found or access denied.'
      });
    }

    // Get specific revision
    const [revs] = await db.query(
      'SELECT title, content, words FROM document_revisions WHERE document_id = ? AND version_number = ?',
      [docId, versionNumber]
    );

    if (revs.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Revision v${versionNumber} not found.`
      });
    }

    const targetRev = revs[0];

    // Get latest revision number
    const [maxRows] = await db.query(
      'SELECT COALESCE(MAX(version_number), 0) AS maxVersion FROM document_revisions WHERE document_id = ?',
      [docId]
    );
    const newVersion = (maxRows[0].maxVersion || 0) + 1;

    // Update document
    await db.query(
      'UPDATE documents SET title = ?, content = ?, words = ?, excerpt = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [targetRev.title, targetRev.content, targetRev.words, generateExcerpt(targetRev.content), docId]
    );

    // Record new restore revision
    await db.query(
      'INSERT INTO document_revisions (document_id, user_id, version_number, title, content, words, change_summary) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [docId, userId, newVersion, targetRev.title, targetRev.content, targetRev.words, `Restored from v${versionNumber}`]
    );

    return res.json({
      success: true,
      message: `Document restored successfully from v${versionNumber} (now v${newVersion}).`,
      document: {
        id: String(docId),
        title: targetRev.title,
        content: targetRev.content,
        words: targetRev.words,
        version: newVersion
      }
    });
  } catch (err) {
    console.error('[RestoreRevision Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to restore revision: ' + err.message
    });
  }
}

module.exports = {
  getDocuments,
  getDocumentById,
  createDocument,
  updateDocument,
  deleteDocument,
  getRevisions,
  restoreRevision
};
