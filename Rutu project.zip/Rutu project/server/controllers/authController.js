const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getPool, isDbConnected } = require('../config/db');

const JWT_SECRET = process.env.JWT_SECRET || 'docbuilder_jwt_secret_rcpit_group20_2026';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

/**
 * Register a new user
 * POST /api/auth/register
 */
async function register(req, res) {
  try {
    const { fullName, email, password, rollNo } = req.body;

    if (!fullName || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Full name, email, and password are required.'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.'
      });
    }

    const emailNormalized = email.trim().toLowerCase();
    const db = getPool();

    // Check existing email
    const [existing] = await db.query('SELECT id FROM users WHERE email = ?', [emailNormalized]);
    if (existing.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'An account with this email already exists. Please log in.'
      });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Insert user
    const [result] = await db.query(
      'INSERT INTO users (full_name, email, password_hash, roll_no) VALUES (?, ?, ?, ?)',
      [fullName.trim(), emailNormalized, passwordHash, rollNo ? rollNo.trim() : null]
    );

    const userId = result.insertId;

    // Seed a welcome project synopsis document for new user
    const welcomeDocContent = `# Welcome to Markdown Documentation Site Builder\n> Authored by **${fullName.trim()}**\n\n---\n\n## Getting Started\nThis workspace lets you write structured Markdown and produces publication-ready HTML documentation.\n\n### Next Steps:\n- [x] Create your account\n- [ ] Write your first technical documentation article\n- [ ] Export to standalone HTML or .md\n`;

    const [docRes] = await db.query(
      'INSERT INTO documents (user_id, title, category, content, excerpt, words) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, 'Getting Started with DocBuilder', 'Guide', welcomeDocContent, 'Quick onboarding guide for your new documentation repository.', 65]
    );

    await db.query(
      'INSERT INTO document_revisions (document_id, user_id, version_number, title, content, words, change_summary) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [docRes.insertId, userId, 1, 'Getting Started with DocBuilder', welcomeDocContent, 65, 'Initial document version']
    );

    const userPayload = {
      id: userId,
      fullName: fullName.trim(),
      email: emailNormalized,
      rollNo: rollNo ? rollNo.trim() : null
    };

    const token = jwt.sign(userPayload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    return res.status(201).json({
      success: true,
      message: 'Registration successful!',
      token,
      user: userPayload
    });
  } catch (err) {
    console.error('[Register Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to register account: ' + err.message
    });
  }
}

/**
 * Login user
 * POST /api/auth/login
 */
async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required.'
      });
    }

    const emailNormalized = email.trim().toLowerCase();
    const db = getPool();

    const [users] = await db.query(
      'SELECT id, full_name, email, password_hash, roll_no FROM users WHERE email = ?',
      [emailNormalized]
    );

    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    const user = users[0];
    const isMatch = await bcrypt.compare(password, user.password_hash);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    const userPayload = {
      id: user.id,
      fullName: user.full_name,
      email: user.email,
      rollNo: user.roll_no
    };

    const token = jwt.sign(userPayload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    return res.json({
      success: true,
      message: 'Logged in successfully!',
      token,
      user: userPayload
    });
  } catch (err) {
    console.error('[Login Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Login failed: ' + err.message
    });
  }
}

/**
 * Get currently authenticated user profile
 * GET /api/auth/me
 */
async function getMe(req, res) {
  try {
    const db = getPool();
    const [users] = await db.query(
      'SELECT id, full_name, email, roll_no, created_at FROM users WHERE id = ?',
      [req.user.id]
    );

    if (users.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    return res.json({
      success: true,
      user: users[0]
    });
  } catch (err) {
    console.error('[GetMe Error]', err);
    return res.status(500).json({
      success: false,
      message: 'Error fetching user profile.'
    });
  }
}

module.exports = {
  register,
  login,
  getMe
};
