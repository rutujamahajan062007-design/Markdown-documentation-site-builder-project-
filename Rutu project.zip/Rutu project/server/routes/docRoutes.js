const express = require('express');
const router = express.Router();
const docController = require('../controllers/docController');
const { requireAuth, optionalAuth } = require('../middleware/authMiddleware');

// Document CRUD endpoints
router.get('/', requireAuth, docController.getDocuments);
router.get('/:id', optionalAuth, docController.getDocumentById);
router.post('/', requireAuth, docController.createDocument);
router.put('/:id', requireAuth, docController.updateDocument);
router.delete('/:id', requireAuth, docController.deleteDocument);

// Document Revisions endpoints
router.get('/:id/revisions', requireAuth, docController.getRevisions);
router.post('/:id/revisions/:version/restore', requireAuth, docController.restoreRevision);

module.exports = router;
