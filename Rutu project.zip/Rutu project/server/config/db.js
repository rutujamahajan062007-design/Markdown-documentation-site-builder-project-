const mysql = require('mysql2/promise');
const dotenv = require('dotenv');

dotenv.config();

const dbUri = process.env.DATABASE_URL || process.env.MYSQL_URL;

const dbConfig = dbUri
  ? {
      uri: dbUri,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      ssl: process.env.DB_SSL === 'false' ? undefined : { rejectUnauthorized: false }
    }
  : {
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '3306', 10),
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'docbuilder_db',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      charset: 'utf8mb4',
      ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined
    };

// Main pool connected to the application database
let pool = null;
let isConnected = false;

function getPool() {
  if (!pool) {
    pool = mysql.createPool(dbConfig);
  }
  return pool;
}

/**
 * Automatically ensures docbuilder_db database and tables exist.
 * Runs on server startup.
 */
async function initDatabase() {
  try {
    // 1. Try to ensure database exists (only if not using a pre-configured URI and not on cloud)
    if (!dbUri && dbConfig.database) {
      try {
        const adminConn = await mysql.createConnection({
          host: dbConfig.host,
          port: dbConfig.port,
          user: dbConfig.user,
          password: dbConfig.password,
          ssl: dbConfig.ssl
        });

        await adminConn.query(
          `CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
        );
        await adminConn.end();
      } catch (adminErr) {
        // Many managed cloud MySQL services restrict CREATE DATABASE.
        // It's safe to continue to connecting directly to the target database.
        console.log(`[Database Notice] Note: Skipping CREATE DATABASE (${adminErr.message})`);
      }
    }

    // 2. Connect pool to the database and verify
    const db = getPool();
    const [test] = await db.query('SELECT 1 + 1 AS result');
    if (test) {
      isConnected = true;
      const targetHost = dbUri ? 'cloud database URL' : `${dbConfig.host}:${dbConfig.port}`;
      console.log(`[Database] Connected to MySQL database successfully on ${targetHost}`);
    }

    // 3. Ensure tables exist
    await db.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(120) NOT NULL,
        email VARCHAR(160) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        roll_no VARCHAR(30) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_users_email (email)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await db.query(`
      CREATE TABLE IF NOT EXISTS documents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(60) NOT NULL DEFAULT 'General',
        content MEDIUMTEXT NOT NULL,
        excerpt VARCHAR(500) NULL,
        words INT NOT NULL DEFAULT 0,
        is_public BOOLEAN NOT NULL DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_docs_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        INDEX idx_docs_user (user_id),
        INDEX idx_docs_category (category)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await db.query(`
      CREATE TABLE IF NOT EXISTS document_revisions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        document_id INT NOT NULL,
        user_id INT NOT NULL,
        version_number INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        content MEDIUMTEXT NOT NULL,
        words INT NOT NULL DEFAULT 0,
        change_summary VARCHAR(255) DEFAULT 'Saved revision',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_rev_doc FOREIGN KEY (document_id) REFERENCES documents (id) ON DELETE CASCADE,
        CONSTRAINT fk_rev_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        UNIQUE KEY uq_doc_version (document_id, version_number),
        INDEX idx_rev_doc (document_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // 4. Check if demo user exists, if not seed
    const [users] = await db.query('SELECT id FROM users LIMIT 1');
    if (users.length === 0) {
      // Demo password: password123
      const demoHash = '$2a$10$vI8aWBnW3fID.ZQ4/zo1G.qH0.6Fk2k2eK1aNvxZzWjWwU8uW7Jiy';
      const [insertUser] = await db.query(
        'INSERT INTO users (full_name, email, password_hash, roll_no) VALUES (?, ?, ?, ?)',
        ['Rutuja Mahajan', 'rutuja@rcpit.ac.in', demoHash, 'IT040']
      );

      const userId = insertUser.insertId;

      // Seed starter docs
      const starterDocs = [
        {
          title: 'REST API Authentication & Endpoints Guide',
          category: 'API',
          excerpt: 'Comprehensive API specification detailing JWT authentication, header authorizations, rate-limiting, and endpoints for document CRUD operations.',
          content: `# REST API Authentication & Endpoints Guide\n> **Version 1.2.0** • Authored by Backend Team\n\n---\n\n## 1. Authentication Overview\nAll API requests require a JSON Web Token (JWT) provided in the authorization header:\n\`\`\`http\nAuthorization: Bearer <your_jwt_token_here>\n\`\`\`\n\n## 2. Key Endpoints\n\n| Method | Endpoint | Description | Access |\n| :--- | :--- | :--- | :--- |\n| \`POST\` | \`/api/auth/login\` | Authenticate and obtain JWT token | Public |\n| \`GET\` | \`/api/docs\` | List all user documents | Private |\n| \`POST\` | \`/api/docs\` | Create or update a document | Private |\n| \`DELETE\`| \`/api/docs/:id\` | Remove a document from database | Private |\n\n## 3. Response Status Codes\n- \`200 OK\`: Request completed successfully.\n- \`400 Bad Request\`: Missing required fields.\n- \`401 Unauthorized\`: Missing or invalid bearer token.\n- \`500 Internal Server Error\`: Database connection error.\n`,
          words: 680
        },
        {
          title: 'MySQL Database Schema & ER Model',
          category: 'Database',
          excerpt: 'Relational database schema definitions, primary keys, foreign constraints, and indexing strategy for users and documentation revisions.',
          content: `# MySQL Database Schema & ER Model\n> **Project-I Architecture Document** • Group 20\n\n---\n\n## 1. Users Table (\`users\`)\nStores registered students, developers, and administrators.\n\n\`\`\`sql\nCREATE TABLE users (\n  id INT AUTO_INCREMENT PRIMARY KEY,\n  full_name VARCHAR(120) NOT NULL,\n  email VARCHAR(160) UNIQUE NOT NULL,\n  password_hash VARCHAR(255) NOT NULL,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\`\`\`\n\n## 2. Documents Table (\`documents\`)\nStores markdown source text, rendered status, and author foreign keys.\n\n\`\`\`sql\nCREATE TABLE documents (\n  id INT AUTO_INCREMENT PRIMARY KEY,\n  user_id INT NOT NULL,\n  title VARCHAR(200) NOT NULL,\n  content MEDIUMTEXT NOT NULL,\n  category VARCHAR(50) DEFAULT 'General',\n  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE\n);\n\`\`\`\n`,
          words: 520
        },
        {
          title: 'Frontend Architecture & Styling Standards',
          category: 'UI / UX',
          excerpt: 'UI design guidelines, CSS custom properties hierarchy, typography rules with Inter font, and marked.js rendering best practices.',
          content: `# Frontend Architecture & Styling Standards\n> **Design Philosophy**: Minimalist, distraction-free, Notion-like clean workspace.\n\n---\n\n## 1. Color System\nOur palette centers on neutral slate tones with indigo accents:\n- **Canvas**: \`#f8fafc\`\n- **Dark Header**: \`#0f172a\`\n- **Brand Primary**: \`#4f46e5\`\n- **Success Badge**: \`#10b981\`\n\n## 2. Typography Rules\n- Main body: \`Inter, sans-serif\` for readability.\n- Code fences & gutter: \`JetBrains Mono, monospace\`.\n\n## 3. Split-Screen Workflow\nThe editor splits screen real estate evenly:\n1. Left pane for raw Markdown input.\n2. Right pane for instantaneous HTML translation.\n`,
          words: 610
        },
        {
          title: 'Project Synopsis & System Requirements',
          category: 'Synopsis',
          excerpt: 'Official Semester III synopsis document submitted to RCPIT Shirpur. Details group members, project guide Prof. A.Z. Ansari, and objectives.',
          content: `# Semester Project-I Synopsis: Markdown Documentation Site Builder\n**Semester III • Academic Year [2025-26]**  \n**The Shirpur Education Society's R. C. Patel Institute of Technology, Shirpur**\n\n---\n\n### Project Guide:\n**Prof. A.Z. Ansari** • Department of Information Technology\n\n### Group 20 Members:\n1. **Rutuja Mahendrakumar Mahajan** (IT040 • PRN: 251109054)\n2. **Tanushri Nitin Bhadhane** (IT030 • PRN: 251109034)\n3. **Gayatri Vijaysing Thakur** (IT033 • PRN: 251109045)\n4. **Bhumika Chetan Patil** (IT059 • PRN: 251109076)\n\n---\n\n### Abstract Summary:\nDocumentation is an essential part of software engineering. Handcrafting HTML documentation can be tedious. This web application enables users to write simple Markdown and automatically produces structured, elegant documentation websites with zero build configuration.\n`,
          words: 890
        }
      ];

      for (const doc of starterDocs) {
        const [docRes] = await db.query(
          'INSERT INTO documents (user_id, title, category, content, excerpt, words) VALUES (?, ?, ?, ?, ?, ?)',
          [userId, doc.title, doc.category, doc.content, doc.excerpt, doc.words]
        );
        await db.query(
          'INSERT INTO document_revisions (document_id, user_id, version_number, title, content, words, change_summary) VALUES (?, ?, ?, ?, ?, ?, ?)',
          [docRes.insertId, userId, 1, doc.title, doc.content, doc.words, 'Initial document version']
        );
      }
      console.log('[Database] Seeded starter documents and demo account (rutuja@rcpit.ac.in)');
    }
  } catch (err) {
    isConnected = false;
    console.error('[Database Warning] Could not connect to MySQL:', err.message);
    console.error('[Database Warning] Please ensure MySQL is running and DB_PASSWORD in .env is correct.');
  }
}

module.exports = {
  getPool,
  initDatabase,
  isDbConnected: () => isConnected
};
