const express = require('express');
const path = require('path');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const { initDatabase, isDbConnected } = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const docRoutes = require('./routes/docRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health Check API
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'Markdown Documentation Site Builder API',
    databaseConnected: isDbConnected(),
    timestamp: new Date().toISOString()
  });
});

// REST API Routes
app.use('/api/auth', authRoutes);
app.use('/api/docs', docRoutes);

// Static Frontend Files
const clientDir = path.join(__dirname, '..', 'client');
app.use(express.static(clientDir));

// Clean URL Route Mappings for Netlify parity
app.get('/', (req, res) => {
  res.sendFile(path.join(clientDir, 'index.html'));
});

app.get('/editor', (req, res) => {
  res.sendFile(path.join(clientDir, 'editor.html'));
});

app.get('/my-docs', (req, res) => {
  res.sendFile(path.join(clientDir, 'my-docs.html'));
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('[Unhandled Error]', err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

// Start Server
async function start() {
  await initDatabase();
  app.listen(PORT, () => {
    console.log(`================================================================`);
    console.log(`  Markdown Documentation Site Builder - Backend Running`);
    console.log(`  Local Server:  http://localhost:${PORT}`);
    console.log(`  Editor View:   http://localhost:${PORT}/editor`);
    console.log(`  Documents:     http://localhost:${PORT}/my-docs`);
    console.log(`  API Health:    http://localhost:${PORT}/api/health`);
    console.log(`================================================================`);
  });
}

start();
